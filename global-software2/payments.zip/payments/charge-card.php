<?php
/**
 * Created by PhpStorm.
 * User: prasanjeet
 * Date: 4/19/18
 * Time: 11:19 PM
 */
error_reporting(E_ALL); ini_set('display_errors', 1);

require 'vendor/autoload.php';
use net\authorize\api\contract\v1 as AnetAPI;
use net\authorize\api\controller as AnetController;
define("AUTHORIZENET_LOG_FILE", "phplog");






function chargeCreditCard($amount)
{
    $servername = "localhost";
    $username = "wwwdot32_dot_adm";
    $password = "pass_dot@741";
    $dbname = "dot_tracker";


    $conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "SELECT * FROM dot_tracker_authorizationForm where id=".$_GET['id'];
    $result = $conn->query($sql);

    $processId=$_GET['id'].'-CCA';

    $cc_name='';
    $cc_number='';
    $cc_expdate='';
    $cc_seccode='';

    $auth_name='';
    $auth_fname='';
    $auth_lname='';
    $auth_company='';
    $address='';
    $city='';
    $state='';
    $zipcode='';
    $country='USA';

    $email='';

    $orderDescription='DOT Operating Authority';



    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {

            $cc_name=$row['cc_name'];
            $cc_number=$row['cc_number'];
            $cc_expdate=$row['cc_expdate'];
            $cc_seccode=$row['cc_seccode'];

            $auth_name=$row['auth_name'];
            $auth_phoneno=$row['auth_phoneno'];

            $auth_company=$row['auth_company'];
            $address=$row['address'];
            $city=$row['city'];
            $state=$row['state'];
            $zipcode=$row['zipcode'];
            $email=$row['auth_email'];
        }
    }

    $conn->close();

    $cc_number=str_replace(' ','',$cc_number);
    $name=explode(' ',$auth_name);
    $auth_fname=$name[0];
    $auth_lname=$name[1];

    //echo $cc_number; die;



    /* Create a merchantAuthenticationType object with authentication details
       retrieved from the constants file */
    $merchantAuthentication = new AnetAPI\MerchantAuthenticationType();
    $merchantAuthentication->setName('3zPMveP25d');
    $merchantAuthentication->setTransactionKey('5Ye2C4g23c4j3pDt');

    // Set the transaction's refId
    $refId = 'ref' . time();
    // Create the payment data for a credit card
    $creditCard = new AnetAPI\CreditCardType();
    $creditCard->setCardNumber($cc_number);
    $creditCard->setExpirationDate($cc_expdate);
    $creditCard->setCardCode($cc_seccode);
    // Add the payment data to a paymentType object
    $paymentOne = new AnetAPI\PaymentType();
    $paymentOne->setCreditCard($creditCard);
    // Create order information
    $order = new AnetAPI\OrderType();
    $order->setInvoiceNumber($processId);
    $order->setDescription($orderDescription);
    // Set the customer's Bill To address
    $customerAddress = new AnetAPI\CustomerAddressType();
    $customerAddress->setFirstName($auth_fname);
    $customerAddress->setLastName($auth_lname);
    $customerAddress->setCompany($auth_company);
    $customerAddress->setAddress($address);
    $customerAddress->setCity($city);
    $customerAddress->setState($state);
    $customerAddress->setZip($zipcode);
    $customerAddress->setPhoneNumber($auth_phoneno);
    $customerAddress->setCountry($country);
    // Set the customer's identifying information
    $customerData = new AnetAPI\CustomerDataType();
    $customerData->setType("individual");
    $customerData->setId(rand(99999,9999999));
    $customerData->setEmail($email);
    // Add values for transaction settings
    $duplicateWindowSetting = new AnetAPI\SettingType();
    $duplicateWindowSetting->setSettingName("duplicateWindow");
    $duplicateWindowSetting->setSettingValue("60");
    // Add some merchant defined fields. These fields won't be stored with the transaction,
    // but will be echoed back in the response.
   /* $merchantDefinedField1 = new AnetAPI\UserFieldType();
    $merchantDefinedField1->setName("customerLoyaltyNum");
    $merchantDefinedField1->setValue("1128836273");
    $merchantDefinedField2 = new AnetAPI\UserFieldType();
    $merchantDefinedField2->setName("favoriteColor");
    $merchantDefinedField2->setValue("blue");*/
    // Create a TransactionRequestType object and add the previous objects to it
    $transactionRequestType = new AnetAPI\TransactionRequestType();
    $transactionRequestType->setTransactionType("authCaptureTransaction");
    $transactionRequestType->setAmount($amount);
    $transactionRequestType->setOrder($order);
    $transactionRequestType->setPayment($paymentOne);
    $transactionRequestType->setBillTo($customerAddress);
    $transactionRequestType->setCustomer($customerData);
    $transactionRequestType->addToTransactionSettings($duplicateWindowSetting);
    /*$transactionRequestType->addToUserFields($merchantDefinedField1);
    $transactionRequestType->addToUserFields($merchantDefinedField2);*/
    // Assemble the complete transaction request
    $request = new AnetAPI\CreateTransactionRequest();
    $request->setMerchantAuthentication($merchantAuthentication);
    $request->setRefId($refId);
    $request->setTransactionRequest($transactionRequestType);
    // Create the controller and get the response
    $controller = new AnetController\CreateTransactionController($request);
    $response = $controller->executeWithApiResponse(\net\authorize\api\constants\ANetEnvironment::SANDBOX);

    if ($response != null) {
        // Check to see if the API request was successfully received and acted upon
        if ($response->getMessages()->getResultCode() == 'Ok') {
            // Since the API request was successful, look for a transaction response
            // and parse it to display the results of authorizing the card
            $tresponse = $response->getTransactionResponse();
            $resp=array();
            if ($tresponse != null && $tresponse->getMessages() != null) {
                $resp=array(
                  'trans_id'=>$tresponse->getTransId(),
                   'response_code'=>$tresponse->getResponseCode(),
                    'message_code'=>$tresponse->getMessages()[0]->getCode(),
                    'auth_code'=>$tresponse->getAuthCode(),
                    'desc'=>$tresponse->getMessages()[0]->getDescription(),
                    'success'=>'true');

            } else {

                $resp=array(
                    'success'=>'false',

                );

                if ($tresponse->getErrors() != null) {

                    $resp=array(
                        'success'=>'false',
                        'err_code'=>$tresponse->getErrors()[0]->getErrorCode(),
                        'err_message'=>$tresponse->getErrors()[0]->getErrorText()
                    );


                }
            }
            // Or, print errors if the API request wasn't successful
        } else {

            $resp=array(
                'success'=>'false',

            );
            $tresponse = $response->getTransactionResponse();

            if ($tresponse != null && $tresponse->getErrors() != null) {
                $resp=array(
                    'success'=>'false',
                    'err_code'=>$tresponse->getErrors()[0]->getErrorCode(),
                    'err_message'=>$tresponse->getErrors()[0]->getErrorText()
                );

            } else {
                $resp=array(
                    'success'=>'false',
                    'err_code'=>$response->getMessages()->getMessage()[0]->getCode(),
                    'err_message'=>$response->getMessages()->getMessage()[0]->getText()
                );

            }
        }
    } else {
        $resp=array(
            'success'=>'false',

        );
        echo  "No response returned \n";
    }
    echo json_encode($resp);
}
if (!defined('DONT_RUN_SAMPLES')) {
    $servername = "localhost";
    $username = "root";
    $password = "root";
    $dbname = "dot_tracker";


    $conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "SELECT * FROM dot_tracker_authorizationForm where id=".$_GET['id'];
    $result = $conn->query($sql);

    $auth_amount=0;

    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {

            $auth_amount=$row['auth_amount'];
        }
    }

    $conn->close();

    $auth_amount=str_replace('$','',$auth_amount);
    chargeCreditCard($auth_amount);
}

