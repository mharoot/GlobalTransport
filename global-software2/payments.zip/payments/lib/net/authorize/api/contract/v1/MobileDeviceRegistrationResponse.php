<?php

namespace net\authorize\api\contract\v1;

/**
 * Class representing MobileDeviceRegistrationResponse
 */
class MobileDeviceRegistrationResponse extends ANetApiResponseType
{


}

