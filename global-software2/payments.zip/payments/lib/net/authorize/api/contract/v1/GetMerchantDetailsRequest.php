<?php

namespace net\authorize\api\contract\v1;

/**
 * Class representing GetMerchantDetailsRequest
 */
class GetMerchantDetailsRequest extends ANetApiRequestType
{


}

